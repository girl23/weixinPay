//
//  AppDelegate.h
//  WeChatPayDemo
//
//  Created by Chaosky on 15/9/24.
//  Copyright (c) 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

